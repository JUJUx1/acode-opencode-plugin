# OpenCode AI Assistant

AI coding assistant for Acode powered by OpenCode.

## Features
- Complete code
- Debug errors  
- Explain code
- Generate new files

## Setup
1. Run OpenCode server in Termux: `proot-distro login ubuntu && opencode serve --port 4000`
2. Tap 🤖 in Acode toolbar
3. Select a mode and tap Run
